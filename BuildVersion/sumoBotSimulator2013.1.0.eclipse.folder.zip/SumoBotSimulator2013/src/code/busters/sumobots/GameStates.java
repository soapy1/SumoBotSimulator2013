package code.busters.sumobots;

// An enum that defines the different states for the program
public enum GameStates {
	Load,
	Build,
	Simulation, 
	Settings
}

