SumoBotSimulator2013
====================

Hello and welcome to Sumo Bot Simulator 2013.  If you are smart then you are reading this.  Congratulations!  You will do great on this assignment.  If you are feeling unsure of yourselves, that is all right, we have been there too when we did this project in SPH4U.  In any case, we are here to help you.

USAGE INSTRUCTIONS:
	1.	You most probably downloaded this program in a .zip file.  Make sure to extract the file (if you are reading this you probably did that already).
	2.	Go into the directory that the file was extracted into.  There should be a couple of files: a .jar file, a README file and another directory called files.
	3.	The actual program you want to use is the .jar file.  Just double click it and it should open up.  If it does not that propably means you don't have a proper version of java running on your computer.  You can easily dowload and install the latest version of java on your computer.  (If you are unsure of how to do this, just google it.)
	4.	Now this part is important, the directory called file has important data for the SumoBotSimulator2013 program.  Basically, if you want to move the application to another directory or fole on your computer, you can not just move the .jar file, you need to move the whole directory (the one that you unzipped).  The moral of the story is, do not move things around inside the SumoBotSimulator2013 folder.
	5.	Build an awesome robot and win USC!  (Also, don't forget to have fun)  

NOTE:  If you are having a lot of trouble you can contact us as codexbusters@gmail.com

Programmed By:        Jessa Mae Alcantara, Sophia Castellarin, Mike Morelli, Joey Venterlla, Dan Yeomans, and James Zhu.

Programmed For:       Bishop Allen Academy

Due:                  June 7, 2013

Program Description:  An application that allows the user to virtually build a Sumo Bot.  The application is designed to
                      help grade 12 students design and build a sumo bot for their end of semester project.  However, it
                      can also be used by anyone else.

Development Blog:     http://sumobots.blogspot.ca/


